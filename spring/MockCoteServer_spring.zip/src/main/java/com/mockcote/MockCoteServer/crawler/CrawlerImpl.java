package com.mockcote.MockCoteServer.crawler;

import org.springframework.stereotype.Component;

@Component
public class CrawlerImpl implements Crawler {

}
