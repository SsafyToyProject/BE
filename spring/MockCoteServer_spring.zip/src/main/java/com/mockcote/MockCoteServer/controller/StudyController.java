package com.mockcote.MockCoteServer.controller;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.mockcote.MockCoteServer.dto.Study;
import com.mockcote.MockCoteServer.dto.User;
import com.mockcote.MockCoteServer.model.service.StudyService;
import com.mockcote.MockCoteServer.model.service.UserService;

import lombok.RequiredArgsConstructor;


@RestController
@RequiredArgsConstructor
@RequestMapping("/study")
public class StudyController {
	
    private final StudyService studyService;
    private final UserService userService;    
	
////	스터디 생성
//    @PostMapping // POST: /study
//    public ResponseEntity<Map<String, Object>> handleRegisterStudy(@RequestBody Map<String, String> requestBody, UriComponentsBuilder uriBuilder) {
//    	
////    	요청 값 추출
//    	int ownerId = Integer.parseInt(requestBody.get("owner_id"));
//    	String name = requestBody.get("name");
//        String description = requestBody.get("description");
//    	
//     // code 생성 (랜덤 문자열 생성)
//        String code = generateStudyCode();
//        
////		StudyDto 생성
//        Study newStudy = new Study(-1, ownerId, name, description, code, null);
//        
//     // 서비스 호출하여 스터디 등록
//        Study registeredStudy = studyService.addStudy(newStudy);
//        
//        // 가입 URL 생성
//        String signupUrl = uriBuilder
//            .path("/study-invite/")
//            .path(registeredStudy.getCode())
//            .build()
//            .toUriString();
//
//        // 응답 데이터 구성
//        Map<String, Object> response = new LinkedHashMap<>();
//        response.put("study_id", registeredStudy.getStudyId());
//        response.put("owner_id", registeredStudy.getOwnerId());
//        response.put("name", registeredStudy.getName());
//        response.put("description", registeredStudy.getDescription());
//        response.put("code", registeredStudy.getCode());
//        response.put("signup_url", signupUrl);
//
//        return ResponseEntity.ok(response);
//    }
//
////	스터디 정보 상세 조회
//    @GetMapping("/{studyId}")  // GET: /study/{studyID}
//    public ResponseEntity<Map<String, Object>> getStudyDetail(@PathVariable int studyId) {
//    	
////    	서비스 호출하여 스터디 정보 조회
//    	Study study = studyService.getStudyById(studyId);
//    	
//    	// 스터디 소유자의 handle 조회
//        User owner = userService.getUserById(study.getOwnerId());  // owner의 user_id로 handle 조회
//
//        // 스터디에 속한 멤버 조회 (User 리스트로 반환)
//        List<Map<String, Object>> studyMembers = studyService.getUsersByStudyId(studyId);
//    	
////    	응답 생성
//        Map<String, Object> response = new LinkedHashMap<>();
//        response.put("study_id", study.getStudyId());
//        response.put("owner_id", study.getOwnerId());
//        response.put("owner_handle", owner.getHandle());
//        response.put("name", study.getName());
//        response.put("description", study.getDescription());
//        response.put("code", study.getCode());
//        response.put("study_member_cnt", studyMembers.size());
//        response.put("study_member", studyMembers);
//        
//        return ResponseEntity.ok(response);
//    }
//    // 랜덤한 스터디 code를 생성하는 메서드
//    private String generateStudyCode() {
//        return Long.toHexString(Double.doubleToLongBits(Math.random()));
//    }
    
//  코드로 스터디 정보 조회
    @GetMapping("/code/{code}") // GET: /study/code/{code}
    public ResponseEntity<Map<String, Object>> getStudyByCode(@PathVariable String code){
//		응답 객체
		Map<String, Object> response = new LinkedHashMap<>();
		
//		서비스에 정보 요청
		Study study = studyService.getStudyByCode(code);
		String ownerHandle = userService.getUserById(study.getOwnerId()).getHandle();
		
//		응답 객체 생성
		response.put("study_id", study.getStudyId());
		response.put("owner_id", study.getOwnerId());
		response.put("ownder_handle", ownerHandle);
		response.put("name", study.getName());
		response.put("description", study.getDescription());
		response.put("code", code);
		
    	return ResponseEntity.ok(response);
    }
    
//  스터디ID로 스터디 삭제
    @DeleteMapping("/{studyId}") // DELETE: /study/{studyId}
    public ResponseEntity<Void> deleteStudyById(@PathVariable int studyId){
//    	서비스에 삭제 요청
    	studyService.deleteStudyById(studyId);
    	return ResponseEntity.noContent().build();
    }
    
//  특정 유저의 스터디 탈퇴
    @DeleteMapping("/user/{studyId}/{userId}") // DELETE: /study/user/{studyId}/{userId}
    public ResponseEntity<Void> leaveStudyById(@PathVariable int studyId, @PathVariable int userId){
//    	서비스에 탈퇴 요청
    	studyService.leaveStudyById(studyId, userId);
    	return ResponseEntity.noContent().build();
    }
    
    
}
